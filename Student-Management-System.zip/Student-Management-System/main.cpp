#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

class Student {
public:
    int id;
    string name;
    float gpa;

    void input() {
        cout << "Enter ID: ";
        cin >> id;
        cout << "Enter name: ";
        cin.ignore();
        getline(cin, name);
        cout << "Enter GPA: ";
        cin >> gpa;
    }

    void display() const {
        cout << "ID: " << id << ", Name: " << name << ", GPA: " << gpa << endl;
    }
};

vector<Student> students;

void addStudent() {
    Student s;
    s.input();
    students.push_back(s);
    cout << "Student added.
";
}

void viewStudents() {
    if (students.empty()) {
        cout << "No students found.
";
        return;
    }
    for (const auto& s : students) {
        s.display();
    }
}

void updateStudent() {
    int id;
    cout << "Enter ID to update: ";
    cin >> id;
    for (auto& s : students) {
        if (s.id == id) {
            cout << "Enter new details:
";
            s.input();
            cout << "Student updated.
";
            return;
        }
    }
    cout << "Student not found.
";
}

void deleteStudent() {
    int id;
    cout << "Enter ID to delete: ";
    cin >> id;
    for (auto it = students.begin(); it != students.end(); ++it) {
        if (it->id == id) {
            students.erase(it);
            cout << "Student deleted.
";
            return;
        }
    }
    cout << "Student not found.
";
}

void saveToFile() {
    ofstream file("students.txt");
    for (const auto& s : students) {
        file << s.id << "," << s.name << "," << s.gpa << endl;
    }
    file.close();
    cout << "Data saved to students.txt
";
}

void loadFromFile() {
    students.clear();
    ifstream file("students.txt");
    Student s;
    string line;
    while (getline(file, line)) {
        size_t pos1 = line.find(',');
        size_t pos2 = line.rfind(',');
        s.id = stoi(line.substr(0, pos1));
        s.name = line.substr(pos1 + 1, pos2 - pos1 - 1);
        s.gpa = stof(line.substr(pos2 + 1));
        students.push_back(s);
    }
    file.close();
}

int main() {
    loadFromFile();
    int choice;
    do {
        cout << "\n--- Student Management System ---\n";
        cout << "1. Add Student\n";
        cout << "2. View Students\n";
        cout << "3. Update Student\n";
        cout << "4. Delete Student\n";
        cout << "5. Save & Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: addStudent(); break;
            case 2: viewStudents(); break;
            case 3: updateStudent(); break;
            case 4: deleteStudent(); break;
            case 5: saveToFile(); cout << "Exiting...
"; break;
            default: cout << "Invalid choice.
";
        }
    } while (choice != 5);

    return 0;
}
