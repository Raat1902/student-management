# Student Management System in C++

## Description
A simple console-based Student Management System that supports:

- Create, Read, Update, Delete (CRUD) operations
- Data persistence using text file (`students.txt`)
- Use of classes and vectors

## How to Run

1. **Compile** the code:
   ```bash
   g++ main.cpp -o student_mgmt
   ```

2. **Run** the executable:
   ```bash
   ./student_mgmt
   ```

## Notes
- All student data is saved to and loaded from `students.txt`
- GPA is stored as a float

## License
MIT
